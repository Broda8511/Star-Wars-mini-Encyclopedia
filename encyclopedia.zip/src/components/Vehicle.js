import React from 'react';
import VehicleSearch from '../search/VehicleSearch';

function Vehicle() {
    return (
        <VehicleSearch/>
    )
}

export default Vehicle