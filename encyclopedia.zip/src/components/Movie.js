import React from 'react';
import MovieSearch from '../search/MovieSearch';

function Movie() {
    return (
        <MovieSearch/>
    )
}

export default Movie
