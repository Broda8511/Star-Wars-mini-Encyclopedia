import React from 'react';
import PersonSearch from '../search/PersonSearch';

function Person() {
    
    return (
        <PersonSearch/>
    )
}

export default Person