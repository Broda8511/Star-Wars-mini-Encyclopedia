import React from 'react';
import PlanetSearch from '../search/PlanetSearch';

function Planet() {
    return (
        <PlanetSearch/>
    )
}

export default Planet