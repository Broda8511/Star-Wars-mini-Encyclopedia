import React from 'react';
import StarshipSearch from '../search/StarshipSearch';

function Starship() {
    return (
        <StarshipSearch/>
    )
}

export default Starship