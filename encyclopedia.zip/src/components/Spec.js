import React from 'react';
import SpecSearch from '../search/SpecSearch';

function Spec() {
    return (
        <SpecSearch/>
    )
}

export default Spec