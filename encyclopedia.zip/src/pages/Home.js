import React from 'react';

function Home() {
    return (
        <div className="card_info">
        <h2>Hello</h2>
            <span>Your eyes can deceive you. Don’t trust them.
            <img src="https://images.unsplash.com/photo-1521985179118-6008b8cef2c2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" alt="SWLogo"/></span>
            
        </div>
    )
}

export default Home;